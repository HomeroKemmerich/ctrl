function dyp = delyp(t,y) 
    dyp = t-pi;
end