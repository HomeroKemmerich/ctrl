function y = history(t)
    y = cos(t);
end