function dy = dely(t,y) 
    dy = t/2;
end