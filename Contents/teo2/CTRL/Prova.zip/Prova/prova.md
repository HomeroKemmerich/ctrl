# Avaliação de controle
$$